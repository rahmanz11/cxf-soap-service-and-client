package alom.bank.server.payload;

public enum AccountTypes {
    CHECKS, A_BOOKLET, SUSTAINABLE_DEVELOPMENT_BOOKLET, YOUTH_BOOKLET
}
