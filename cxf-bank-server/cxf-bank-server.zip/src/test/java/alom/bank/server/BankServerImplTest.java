
package alom.bank.server;

import org.junit.Test;

public class BankServerImplTest {

    @Test
    public void test() {
    }
}
